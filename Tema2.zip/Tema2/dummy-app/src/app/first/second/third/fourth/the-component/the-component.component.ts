import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-the-component',
  templateUrl: './the-component.component.html',
  styleUrls: ['./the-component.component.scss']
})
export class TheComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

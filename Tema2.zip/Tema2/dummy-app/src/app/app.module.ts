import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DummyModuleModule } from './dummy-module/dummy-module.module';
import { FirstModule } from './first/first.module';
import { SecondModule } from './first/second/second.module';
import { ThirdModule } from './first/second/third/third.module';
import { FourthModule } from './first/second/third/fourth/fourth.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DummyModuleModule,
    FirstModule,
    SecondModule,
    ThirdModule,
    FourthModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
